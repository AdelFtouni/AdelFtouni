<?php
include "conn.php";
//$name="sami jaber";
//$email="sami.jaber67@gmail.com";
//$phone=56766755;
//$city="tyr";
//$id = 54;
$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$city=$_POST['address'];
//UPDATE `person` SET `name` = 'hadi jradi' WHERE `person`.`id` = 2
//UPDATE `person` SET `name` = 'hassan hassan' WHERE `person`.`id` = 30;
$sql= "UPDATE `person`
             SET `phone`='$phone',`name`='$name',`email`='$email',`city`='$city'
             WHERE id=$id " ;
//if(mysqli_query($conn,$sql){
   //echo "row updated ";
  //  echo "json_encode($sql)";
//}           
//else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  //}  

  if(mysqli_query($conn, $sql)) {
    echo "<br>jeson_encode($sql).<br>";
    echo "The row is updated successfully";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
 }
        
  ?>