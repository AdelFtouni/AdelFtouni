<?php
include "conn.php";
$id=$_POST['id'];
//$id=2;
$sql="DELETE from `person` WHERE id=$id";
//$conn->query($sql)

if(mysqli_query($conn,$sql)){
    echo("<br> The row is deleted successfully <br>");
    echo json_encode($sql);
}
else{
    "Error: ".$sql. "<br>" . mysqli_error($conn);
}
?>