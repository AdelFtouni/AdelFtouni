<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
	<link rel="stylesheet" href="style2.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="alert.js"></script>
</head>
<body>





	

			<form action="save.php" method="post">
			<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="">
						<h2 class="blocktext">Sign Up</h2>
					</div>
					<div class="col-sm-6">
							</div>

				</div>
	
			</div>
				<div class="modal-header">						
				
				
				</div>
				<div class="modal-body">					
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="name" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Phone</label>
						<input class="form-control" name="phone" required></textarea>
					</div>
					<div class="form-group">
						<label>Address</label>
						<input type="text" name="city" class="form-control" required>
					</div>	
					<div class="form-group">
						<label>Password</label>
						<input type="text" name="password" class="form-control" required>
					</div>				
				</div>
				<div class="col-sm-6">
				
					<!--<input action="save.php" type="submit" class="btn btn-success" value="Add">-->
					<button  type="submit" class="btn btn-success">Sign Up</button>
				</div>
			</form>


</body>
</html>