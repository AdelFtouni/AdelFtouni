<!DOCTYPE html>
<html lang="en">
<head>
  
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <h1>upload Image</h1>
    <form action ="upload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="image">
    <input type="submit" name="upload" value="upload">
</form><br>
<h1>view uploaded Image</h1>
    <form action ="view.php" method="post" enctype="multipart/form-data">
  <button>view Image</button>
</form>
       </body>
</html>