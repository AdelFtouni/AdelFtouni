<?php
$servername="localhost";
$username="root";
$password="";
$dbname="users";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn){
    echo "<br>";
}
else{
    die("connection error".mysqli_connect_error());
}
// mysqli_connect_error() to know what and in wich line of the code the error is.



?>