<?php
error_reporting(0);
include 'conn.php';
if(count($_POST)>0) {
$name=$_POST['name'];
$query=	 "SELECT * FROM person WHERE name='$name'";
$result = mysqli_query($conn,$query);
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Search</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style2.css">

</head>
<body>
<div class="container-xl">

<div class="table-responsive">
<div class="">	<h2>Search <b>results</b></h2></div>
</div>
</div>

<table class="table table-striped table-hover">
<tr>
<td><b>Name</b></td>
<td><b>Email</b></td>


</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["name"]; ?></td>
<td><?php echo $row["email"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>

</body>
</html>