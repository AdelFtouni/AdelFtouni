<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style2.css">
</head>
<body>
    
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="">
						<h2 class="">the user is added successfully</h2>
            <?php
include "conn.php";

$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$city=$_POST['city'];
$password=$_POST['password'];
$sql="INSERT INTO `person` (`name`, `email`, `phone`,`city`,`password`) VALUES ('$name', '$email', '$phone','$city','$password')";
//if(mysqli_query($conn,$sql)){
  //  echo jeson_encode($sql);
//}

if(mysqli_query($conn, $sql)) {
    echo "<br>jeson_encode($sql).<br>";
    echo "New record created successfully";

    
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

//we can also this code:
  //if ($conn->query($sql) === TRUE) {
      //echo "<br>jeson_encode($sql).<br>";
    //echo "New record created successfully";
  //} else {
    //echo "Error: " . $sql . "<br>" . $conn->error;
  
?>
					</div>
					<div class="col-sm-6">
							</div>

				</div>
	
			</div>
  
</body>
</html>
