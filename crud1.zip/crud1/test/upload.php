<?php
include "conn.php";
$file_name=$_FILES['image']['name'];
$file_tmp=$_FILES['image']['tmp_name'];
$file_type=$_FILES['image']['type'];
$ext=array("jpeg","jpg","png");



$url='http://localhost/test/images/'.$file_name;
//$url=$file_name;
$person_id=4;
$sql="INSERT INTO `images` (`path`, `person_id`) VALUES ('$url', '$person_id')";
if(empty($erros)==true){
  move_uploaded_file($file_tmp,"images/" . $file_name);
  echo"Success upload <br>";
}

if(mysqli_query($conn, $sql)) {
    echo "<br>jeson_encode($sql).<br>";
    echo "Image is uploaded successfully"."<br>";
    echo $file_name;
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
?>