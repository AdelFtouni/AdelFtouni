<?php
include "conn.php";

$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$city=$_POST['city'];
$sql="INSERT INTO `person` (`name`, `email`, `phone`,`city`) VALUES ('$name', '$email', '$phone','$city')";
//if(mysqli_query($conn,$sql)){
  //  echo jeson_encode($sql);
//}

if(mysqli_query($conn, $sql)) {
    echo "<br>jeson_encode($sql).<br>";
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
//we can also this code:
  //if ($conn->query($sql) === TRUE) {
      //echo "<br>jeson_encode($sql).<br>";
    //echo "New record created successfully";
  //} else {
    //echo "Error: " . $sql . "<br>" . $conn->error;
  
?>