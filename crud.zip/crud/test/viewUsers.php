<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
    
<?php
include "conn.php";

$sql='SELECT * from person';
$result=mysqli_query($conn,$sql);
// $result=$conn->query($sql);
//----------
//  if(mysqli_num_rows($result) > 0){
if($result->num_rows>0){
    echo"<table><tr><th>ID</th> <th>Name</th> <th>Email</th> <th>Phone</th> <th>City</th>";
while($row=$result -> fetch_assoc()){
    echo "<tr><td>" . $row["id"]. "</td>"."<td>" . $row["name"]. "</td>"."<td>" . 
    $row["email"]."</td>"."<td>".$row["phone"]."</td>"."<td>".$row["city"]. "</td></tr>";
    }
    echo "</table>";
}  
   // echo "</table>";
    else{
        echo "0 result";
    }
    ?>
</body>
</html>
