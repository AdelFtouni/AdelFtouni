<?php
include "conn.php";
$sql="SELECT * FROM images ";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
while($images=mysqli_fetch_array($res)){
    ?>
    <img src="<?php echo $images['path'] ?> "
    alt="">
    <?php
}
?>
