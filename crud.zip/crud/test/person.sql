-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2022 at 01:29 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(11) NOT NULL,
  `city` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`id`, `name`, `email`, `phone`, `city`) VALUES
(38, 'hadi saadi', 'hadi@gmail.com', 71890223, 'saida'),
(39, 'hadi saadi', 'hadi@gmail.com', 71890223, 'saida'),
(40, 'hadi saadi', 'hadi@gmail.com', 71890223, 'saida'),
(41, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(42, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(44, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(46, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(47, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(48, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(49, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(50, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(51, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(52, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(53, 'jihad ibrahim', 'jihad@gmail.com', 71234223, 'saida'),
(55, 'person1', 'person1@gmail.com', 0, 'zahle'),
(57, 'person2', 'person2@hotmail.com', 78990001, 'nabatieh'),
(58, 'sana ounayssi', 'sana.ounayssi@gmail.com', 0, 'kfarkila'),
(59, 'hahahahhaha', 'hahhaa.12@gmail.com', 87000292, 'zahle'),
(60, '', '', 0, ''),
(61, 'sana ounayssi', 'sana.ounayssi@gmail.com', 0, 'kfarkila'),
(62, '', '', 0, ''),
(63, 'thtr', 'adel.ftouni020@gmail.com', 76137658, 'beirut'),
(64, '', '', 0, ''),
(65, '', '', 0, ''),
(66, 'kam', 'kamel.akhdar@gamil.com', 3898237, 'nabatieh'),
(67, 'adel ftouni', 'adel.ftouni020@gmail.com', 123213131, 'beirut'),
(68, 'adel ftouni', 'adel.ftouni020@gmail.com', 212112121, 'beirut'),
(69, 'adel ftouni', 'adel.ftouni020@gmail.com', 2147483647, 'beirut'),
(70, 'hadi', 'hadi@gmail.com', 45454545, 'beirut'),
(71, 'sami', 'sami@gamil.com', 677677676, 'nabatieh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
