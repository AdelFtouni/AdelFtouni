<?php
include "conn.php";
$sql='SELECT * from person';
$result=mysqli_query($conn,$sql);
// $result=$conn->query($sql);
//----------
//  if(mysqli_num_rows($result) > 0){
if($result->num_rows>0){
while($row=$result -> fetch_assoc()){
    echo "id: ". $row["id"] . "name: " . $row["name"] . "email: ". $row["email"] . "phone: " . $row["phone"] . "city: " . $row["city"]
    . "<br>";
    }}  

    else{
        echo "0 result";
    }
    //In the example above, the data returned by the mysqli_query() function is stored in the $result
    //variable. Each time mysqli_fetch_array() or fetch_assoc() is invoked, it returns the next row from the result set as an
    //array. The while loop is used to loops through all the rows in the result set. Finally the value of individual
   // field can be accessed from the row either by passing the field index or field name to the $row variable
    //like $row['id'] or $row[0], $row['first_name'] or $row[1], $row['last_name'] or $row[2],
    //and $row['email'] or $row[3].
$conn->close();
?>
